# Local dev environment variables
$env:JWT_SECRET = "your-super-secret-jwt-key-change-this-in-production-min-32-chars"
$env:GOOGLE_CLIENT_ID = "your-google-client-id"
$env:GOOGLE_CLIENT_SECRET = "your-google-client-secret"
$env:GROQ_API_KEY = "your-groq-api-key"
$env:SEPAY_API_KEY = "your-sepay-api-key"
$env:SEPAY_ACCOUNT_NUMBER = "your-account-number"
$env:SEPAY_ACCOUNT_NAME = "your-account-name"
$env:SEPAY_BANK_CODE = "your-bank-code"

Write-Host "Environment variables set. Starting Spring Boot..." -ForegroundColor Green
./mvnw spring-boot:run
