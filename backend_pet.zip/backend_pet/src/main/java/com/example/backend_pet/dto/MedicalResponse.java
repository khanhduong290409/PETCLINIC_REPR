package com.example.backend_pet.dto;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@ToString
public class MedicalResponse {
    private Long id;
    private Long appointmentId;
    private String bookingCode;
    private LocalDate appointmentDate;
    private String petName;
    private String petImageUrl;
    private String petSpecies;
    private String diagnosis;
    private String treatment;
    private String prescription;
    private String notes;
    private LocalDate followUpDate;
    private List<String> imageUrls;
}
