import { API_BASE_URL, getAuthHeaders } from './apiClient';

export interface MedicalResponse {
    id: number;
    appointmentId: number;
    bookingCode: string;
    appointmentDate: string;
    petName: string;
    petImageUrl: string;
    petSpecies: string;
    diagnosis: string;
    treatment: string;
    prescription: string;
    notes: string;
    followUpDate: string;
    imageUrls: string[];
}

export interface MedicalRequest {
    diagnosis: string;
    treatment: string;
    prescription: string;
    notes: string;
    followUpDate: string;
    imageUrls: string[];
}

export const medicalRecordApi = {
    async getRecord(bookingCode: string): Promise<MedicalResponse[]> {
        const response = await fetch(`${API_BASE_URL}/medical/${bookingCode}`, {
            headers: getAuthHeaders(),
        });
        if (!response.ok) throw new Error('Failed to fetch medical record');
        return response.json();
    },

    async saveRecord(appointmentId: number, data: MedicalRequest): Promise<MedicalResponse> {
        const response = await fetch(`${API_BASE_URL}/medical/${appointmentId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
            body: JSON.stringify(data),
        });
        if (!response.ok) throw new Error('Failed to save medical record');
        return response.json();
    },

    async getRecordsByPet(petId: number): Promise<MedicalResponse[]> {
        const response = await fetch(`${API_BASE_URL}/medical/pet/${petId}`, {
            headers: getAuthHeaders(),
        });
        if (!response.ok) throw new Error('Failed to fetch pet medical records');
        return response.json();
    },
};
