import { API_BASE_URL, getAuthHeaders } from './apiClient';

export interface ServiceResponse {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  price: number;
  duration: number;
  category: string;
}

export interface AppointmentRequest {
  userId: number;
  petIds: number[];
  serviceIds: number[];
  appointmentDate: string;
  appointmentTime: string;
  notes: string;
}

export interface ServiceInfo {
  id: number;
  title: string;
  price: number;
}

export interface AppointmentResponse {
  id: number;
  bookingCode: string;
  petName: string;
  petSpecies: string;
  petImageUrl: string;
  services: ServiceInfo[];
  doctorName: string | null;
  appointmentDate: string;
  appointmentTime: string;
  status: string;
  notes: string;
  createdAt: string;
}

export const appointmentApi = {
  async getServices(): Promise<ServiceResponse[]> {
    const response = await fetch(`${API_BASE_URL}/services`);
    if (!response.ok) throw new Error('Failed to fetch services');
    return response.json();
  },

  async createAppointments(data: AppointmentRequest): Promise<AppointmentResponse[]> {
    const response = await fetch(`${API_BASE_URL}/appointments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to create appointments');
    return response.json();
  },

  async getAppointments(): Promise<AppointmentResponse[]> {
    const response = await fetch(`${API_BASE_URL}/appointments`, {
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to fetch appointments');
    return response.json();
  },

  async cancelAppointment(appointmentId: number): Promise<AppointmentResponse[]> {
    const response = await fetch(`${API_BASE_URL}/appointments/${appointmentId}/cancel`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to cancel appointment');
    return response.json();
  },
};
